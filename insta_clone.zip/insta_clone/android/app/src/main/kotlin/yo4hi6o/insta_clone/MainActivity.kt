package yo4hi6o.insta_clone

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
